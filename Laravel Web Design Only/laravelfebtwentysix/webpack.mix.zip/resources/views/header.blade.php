<div class="logo">
    <img src="{{asset('image/logo.png')}}" alt="">
</div>
<div class="navigation">
    <ul>
        <li><a href="/">Home</a></li>
    <li><a href="{{url('/portf')}}">Portfolio</a></li>
    <li><a href="{{url('/about')}}">About</a></li>
    <li><a href="{{url('/message')}}">Contact</a></li>
    <li><a href="{{url('/team')}}">Team</a></li>
    </ul>
</div>

