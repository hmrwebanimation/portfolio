<div class="logo">
    <img src="<?php echo e(asset('image/logo.png')); ?>" alt="">
</div>
<div class="navigation">
    <ul>
        <li><a href="/">Home</a></li>
    <li><a href="<?php echo e(url('/portf')); ?>">Portfolio</a></li>
    <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
    <li><a href="<?php echo e(url('/message')); ?>">Contact</a></li>
    <li><a href="<?php echo e(url('/team')); ?>">Team</a></li>
    </ul>
</div>

<?php /**PATH C:\xampp\htdocs\laravelfebtwentysix\resources\views/header.blade.php ENDPATH**/ ?>