<div class="one">
    <img src="<?php echo e(asset('image/logo.png')); ?>" alt="">
</div>
<div class="two">
    <li><a href="/">Home</a></li>
    <li><a href="<?php echo e(url('/portf')); ?>">Portfolio</a></li>
    <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
    <li><a href="<?php echo e(url('/message')); ?>">Contact</a></li>
    <li><a href="<?php echo e(url('/team')); ?>">Team</a></li>
</div>
<div class="three">
    <li><a href="https://www.facebook.com"><img src="<?php echo e(asset('image/facebook.png')); ?>" alt=""></a></li>
    <li><a href="https://www.youtube.com"><img src="<?php echo e(asset('image/youtube.png')); ?>" alt=""></a></li>
    <li><a href="https://www.twitter.com"><img src="<?php echo e(asset('image/twitter.png')); ?>" alt=""></a></li>
    <li><a href="https://www.linkedin.com"><img src="<?php echo e(asset('image/linkedin.png')); ?>" alt=""></a></li>
</div>
<div class="four">
    <label for="">Search</label>
    <input type="text" placeholder="search">
</div>
<div class="c-text">
    <h2 class="copyright">Laravel-Dune &copy; All Rights Reserved 2020.</h2>
</div>

<?php /**PATH C:\xampp\htdocs\laravelfebtwentysix\resources\views/footer.blade.php ENDPATH**/ ?>